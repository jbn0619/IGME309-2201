/*--------------------------------------------------------------------------------------------------
Comments about this program
--------------------------------------------------------------------------------------------------*/
#include "Main.h";
using namespace std;

int main()
{
	cout << "Hello world!\n";

	//Ending the program
	cout << "Press enter to end the program.";

	getchar();

	return 0;
}